import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layer from "./WebPages/Layer";
import Home from "./WebPages/Home";
import Contact from "./WebPages/Contact";
import About from "./WebPages/About";
import Student from "./WebPages/Student";
import LoginPage from "./WebPages/LoginPage";


 function Navigation() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layer/>}>
          <Route index element={<Home/>} />
          <Route path="Contact" element={<Contact/>} />
          <Route path="About" element={<About/>} />
          <Route path="Student" element={<Student/>} />
          <Route path="LoginPage" element={<LoginPage/>} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default Navigation;