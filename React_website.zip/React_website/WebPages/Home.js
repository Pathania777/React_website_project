import { useEffect } from 'react';
import {  useNavigate} from 'react-router-dom';

import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

import  '../index.css';




const Home =() => {

    const navigate = useNavigate()
    useEffect(()=>{

if(!localStorage.getItem('token')){

    navigate('/LoginPage')
}

    },[])
    
  const settings = {
    dots: false,
    infinite: true,
    arrows:false,
    speed: 2000,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 1000,
  };


 

 
  return (
    <div>
      <Slider {...settings}>
        <div className='sl1'>
        </div>
        <div className='sl2'>
        </div>
        <div className='sl3'> 
        </div>
      </Slider>

      <h1 className='prohead'>EXPLORE OUR OTHER BRANDS</h1>

      <div class="products">
                
        
                    
                    <div class="card">
                        
                        <div class="name1"></div>
                        <div class="desc">
                            <p>Banana Republic</p>
                        </div>
                        <div class="read_bt">
                            <a href="#">Read More</a>

                        </div>
                            
                    </div>

                    <div class="card">
                        
                        <div class="name2"></div>
                        <div class="desc">
                            <p>Old Navy</p>
                        </div>
                        <div class="read_bt">
                            <a href="#">Read More</a>

                        </div>
                            
                    </div>

                    <div class="card">
                        
                        <div class="name3"></div>
                        <div class="desc">
                            <p>Levis</p>
                        </div>
                        <div class="read_bt">
                            <a href="#">Read More</a>

                        </div>
                            
                    </div>

                </div>




                <div class="who_sec">
       
            <div class="main_who_sec">
                <div class="who_head">
                    <h1>Who Are We ?</h1>
                </div>
                <div class="who_sub_head">
                    <h3>Live in Levi's</h3>
                </div>
                <div class="who_para">
                    <p>Levi Strauss & Co. is an American clothing company known worldwide for its Levi's brand of denim jeans. It was founded in May 1853 when German-Jewish immigrant Levi Strauss moved from Buttenheim, Bavaria, to San Francisco, California, to open a West Coast branch of his brothers' New York dry goods business.</p>
                </div>
    
                <button class="who_btn">GET A QUOTE</button>
            </div>
        
    </div>

      

    <footer>
        <h3>@2023 Levis</h3>
        <button 
        onClick={()=>{

            localStorage.removeItem('token')
            navigate('/LoginPage')
        }

        }
        
        
        className='btn2'>LogOut</button>
      </footer>
      
    </div>




  );
};


export default Home;