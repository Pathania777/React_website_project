
import { useState, useEffect } from 'react';
import {  useNavigate} from 'react-router-dom';
import  '../index.css';

let indexId = 0;

function Adddata() {
  const navigate = useNavigate()


  useEffect(()=>{

    if(!localStorage.getItem('token')){
    
        navigate('/LoginPage')
    }
    
        },[])
  const [name, setName] = useState('');
  const [roll, setRoll] = useState('');

  const [datainfo, setDatainfo] = useState([]);

  return (
    <>
      <h1>Enter Details of Student.</h1>
      <input
        value={name}
        placeholder='username'
        onChange={e => setName(e.target.value)}
      />
      <input
        value={roll}
        placeholder='UID'
        onChange={e => setRoll(e.target.value)}
      />
    
 <button onClick={() => {
        setDatainfo([
          ...datainfo,
          { id: indexId++, name: name, roll: roll }
        ]);
      }}>Add</button> 
    <table>
       
                    <tr className='head'>
                        <th className='te'>Name</th>
                        <th className='te'>UID</th>

                    </tr>
                    {datainfo.map(emp => (
                                    
                                    <tr key={emp.Id}>
                                        {/* <td>{emp.Id}</td> */}
                                        <td>{emp.name}</td>
                                        <td>{emp.roll}</td>
                                    </tr>
                                ))}
       
                        
    </table>

    <footer>
        <h3>@2023 Levis</h3>
        <button 
        onClick={()=>{

            localStorage.removeItem('token')
            navigate('/LoginPage')
        }

        }
        
        
        className='btn2'>LogOut</button>
      </footer>
    </>
  );
}


export default Adddata;


                    
