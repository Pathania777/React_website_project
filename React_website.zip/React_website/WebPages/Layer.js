import { Outlet, Link } from "react-router-dom";
 import logo from '../Images/gap.png';
import '../index.css';

const Layer = () => {
  return (
    <>
      <nav className="navb">


      <img className="imgur"
              src={logo}
              width="100"
              alt=""
      />
          <navmain className ="navmain">

          <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/Contact">Contact</Link>
          </li>
          <li>
            <Link to="/About">About</Link>
          </li>
          <li>
            <Link to="/Student">Student</Link>
          </li>
          <li>
            <Link to="/LoginPage">LoginPage</Link>
          </li>
          
         
        </ul>
       
          </navmain>


        
      </nav>

      <div class="main-content"><Outlet /></div>
    </>
  )
};

export default Layer;