import {  useNavigate} from 'react-router-dom';

import { useEffect } from 'react';

import  '../index.css';


function About(){
    const navigate = useNavigate()
    useEffect(()=>{

        if(!localStorage.getItem('token')){
        
            navigate('/LoginPage')
        }
        
            },[])

return(

    <>


    <h1 className="about">About US</h1>
    <div>
       <img src='https://source.unsplash.com/user/wsanter'  alt=''  width={1350}  height={500}></img>

       <p className="about-des">SeaWorld Parks & Entertainment is an American theme park and entertainment company headquartered in Orlando, Florida. The company is a subsidiary of SeaWorld Entertainment Inc. and owns and operates thirteen recreational destinations in the United States, including eight theme parks and five water parks</p>

    </div>
    <footer>
        <h3>@2023 Levis</h3>
        <button 
        onClick={()=>{

            localStorage.removeItem('token')
            navigate('/LoginPage')
        }

        }
        
        
        className='btn2'>LogOut</button>
      </footer>
    
    </>
);


}

export default About;