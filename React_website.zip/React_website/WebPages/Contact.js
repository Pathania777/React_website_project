import {  useNavigate} from 'react-router-dom';

import { useEffect } from 'react';
import  '../index.css';
import { FaFacebook } from 'react-icons/fa';
import { FaTwitter } from 'react-icons/fa';
import { FaInstagram } from 'react-icons/fa';




function Contact(){
    const navigate = useNavigate()

    useEffect(()=>{

        if(!localStorage.getItem('token')){
        
            navigate('/LoginPage')
        }
        
            },[])
return(



    <>
    
    <h1 className='contact'>Contact US</h1>
    <div className='map-det'>
            <div className='map'>
                <p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3282.056493516174!2d135.43256217485848!3d34.65327618575743!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6000e861e5498a3b%3A0xfa6e872db14c9b3e!2sZenkoji!5e0!3m2!1sen!2sin!4v1697528805057!5m2!1sen!2sin" width="400" height="300" style={{border:'none'}} allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></p>
            </div>

            <div className='details'>

           

           
            <form>
                    <label>NAME:
                    <input 
                    type="text" 
                    name="username" 
                    
                    
                    />
                    </label>
                    <label> EMAIL ADDRESS:
                    <input 
                        type="email" 
                        name="emailId" 
                        
                
                    />
                    </label>

                    

                    <input type="submit"   className='btn'/>
                
                
            </form>
                        
            </div>

    </div>




    <div className='addsoc'>

          <div className='add'>
            <h1 className='adw'>Address</h1>
                <p>
                Konohana Ward Office,
                1-8-4, Kasugadekita, Konahana-ku, Osaka
                TEL :06-6466-9986
                </p>
          </div>
          <div className='soc'>
              <ul className='socul'>
                <li><FaFacebook/></li>
                <li><FaTwitter/></li>
                <li><FaInstagram/></li>
              </ul>
          </div>
    </div>
    
    

    <footer>
        <h3>@2023 Levis</h3>
        <button 
        onClick={()=>{

            localStorage.removeItem('token')
            navigate('/LoginPage')
        }

        }
        
        
        className='btn2'>LogOut</button>
      </footer>
    </>
);



}

export default Contact;

