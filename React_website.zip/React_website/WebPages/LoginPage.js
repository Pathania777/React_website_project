import React, {useState} from 'react';
 import {  useNavigate} from 'react-router-dom';
import  '../index.css';
 import axios from "axios";




// function  LoginPage(){

// const[email,setEmail]= useState("")
// const[password,setPassword]= useState("")
// const navigate= useNavigate();

// useEffect(() =>{

//   if(localStorage.getItem('user-info')){
//     navigate("/Contact")
//   }


// },[])


// async function login()
// {
//   console.warn(email,password);
//   let item={email,password};
//   let result= await fetch ("http://localhost:8000/user",{

//   method: 'POST',
//   headers:{
//     "Content-type": "application/json",
//     "Accept": "application/json"
//   },
//   body: JSON.stringify(item)

//   });

//   result= await result.json();
//   localStorage.setItem("user-info",JSON.stringify(result))
//   navigate("/Contact")
// }

// return(


//   <>
//   <div className='mainlogin'>
//   <div className='login'>
//     <h1>Login Now</h1>
//     <form >
//         <label>Enter your Email:
//         <input 
//           type="email" 
//           name="username" 
//           onChange={(e)=>setEmail(e.target.value)}
//         />
//         </label>
//         <label>Enter your password:
//         <input 
//           type="password" 
//           name="username" 
//           onChange={(e)=>setPassword(e.target.value)}

//         />
//         </label>
//           <button onClick={login}className='btn1'>Login</button>
//       </form>

//   </div>

//   </div>
  
//   </>
// )


// }

// export default LoginPage;





function LoginPage() {

  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  console.log({ email, password })
  const handleEmail = (e) => {
    setEmail(e.target.value)
  }

  const handlePassword = (e) => {
    setPassword(e.target.value)
  }

  const handleApi = () => {
    console.log({ email, password })
    axios.post('https://reqres.in/api/login', {
      email: email,       

      // email :eve.holt@reqres.in
      // pass:  cityslicka
      password: password
    }).then(result => {
      console.log(result.data)
      alert('success')
      localStorage.setItem('token', result.data.token)
      navigate("/")
    })
      .catch(error => {
        alert('service error')
        console.log(error)
      })
  }

  return (
    <div className="App">
      <h1>LOGIN NOW</h1>
      Email : <input value={email} onChange={handleEmail} type="text" /> <br />
      Password : <input value={password} onChange={handlePassword} type="text" /> <br />
      <button   className ="bts" onClick={handleApi} >Login</button>
    </div>
  );
}

export default LoginPage;
